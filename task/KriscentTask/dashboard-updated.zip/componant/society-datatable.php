<thead>
<tr>
	<th>ID</th>
	<th>Society Name :</th>
	<th>Pincode / Area code / Zip :</th>
	<th>Delivery Charge :</th>
	<th>Action</th>
</tr>
</thead>
<tbody>
<tr>
<td class="text-center">1</td>
<td>Chhawani</td>
<td>324001</td>
<td>20</td>
<td ><div class="btn-group">
	<div class="btn-group">
		<a href="javascript:" class="my-btn btn-primary" data-toggle="modal" data-target="#mySociety">
		<span class="ti-pencil"></span></a>&nbsp;
		<a href="javascript:" class="my-btn btn-danger">
		<span class="ti-trash"></span></a>                                                            
	</div>
</td>
</tr>
<tr>
<td class="text-center">2</td>
<td>Gumanpura-Kota</td>
<td>324007</td>
<td>0</td>
<td >
	<div class="btn-group">
		<a href="javascript:" class="my-btn btn-primary" data-toggle="modal" data-target="#mySociety">
		<span class="ti-pencil"></span></a>&nbsp;
		<a href="javascript:" class="my-btn btn-danger">
		<span class="ti-trash"></span></a>                                                            
	</div>
</td>
</tr>
<tr>
<td class="text-center">3</td>
<td>Mahaveer Nagar</td>
<td>324005</td>
<td>0</td>
<td >
	<div class="btn-group">
		<a href="javascript:" class="my-btn btn-primary" data-toggle="modal" data-target="#mySociety">
		<span class="ti-pencil"></span></a>&nbsp;
		<a href="javascript:" class="my-btn btn-danger">
		<span class="ti-trash"></span></a>                                                            
	</div>
</td>
</tr>
<tr>
<td class="text-center">4</td>
<td>saraswati colony Police line</td>
<td>324001</td>
<td>0</td>
<td >
	<div class="btn-group">
		<a href="javascript:" class="my-btn btn-primary" data-toggle="modal" data-target="#mySociety">
		<span class="ti-pencil"></span></a>&nbsp;
		<a href="javascript:" class="my-btn btn-danger">
		<span class="ti-trash"></span></a>                                                            
	</div>
</td>
</tr>  
</tbody>