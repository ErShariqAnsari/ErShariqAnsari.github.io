<thead>
<tr>
	<th class="text-center">Customer Name</th>
	<th class="text-center">Society</th>
	<th class="text-center">Customer Phone</th>
	<th class="text-center">Date</th>
	<th class="text-center">Time</th>
	<th class="text-center">Order Amount</th>
	<th class="text-center">Status</th>
	<th class="text-center">Action</th>
</tr>
</thead>
<tbody>
   <tr>
      <td>Shariq</td>
      <td>Kota</td>
      <td>900178412132</td>
      <td>01/12/2019</td>
	  <td>01/12/2019 : 12:00</td>      
	  <td>1200</td>
	  <td><span class="badge badge-success"> Active</span></td>
      <td>
         <div class="btn-group">
            <a href="javascript:" class="my-btn btn-primary">
			<span class="ti-pencil"></span></a>&nbsp;
            <a href="javascript:" class="my-btn btn-danger">
            <span class="ti-trash"></span></a>                                                            
         </div>
      </td>
   </tr>   
</tbody>