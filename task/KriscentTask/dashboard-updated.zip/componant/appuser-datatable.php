
	<thead>
		<tr>
			<th>User ID</th>
			<th>Created At</th>
			<th>Created By</th>
			<th>Name</th>
			<th>Phone</th>
			<th>Referral Code</th>
			<th>Referral By Code</th>
			<th>Total Orders</th>
			<th>Wallet</th>
			<th>Total Amount</th>
			<th>Status</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
                                                                                                   
	<tr>
		
		<td>1</td>
		<td>2019-06-18 17:37:33</td>
		<td>App</td>
		<td>tes</td>
		<td>7976338400</td>
		<td>fssunz</td>
		<td></td>

		<td></td>
		<td>10</td> 
<!--                                                            <td>0</td>-->
		<td>0</td> 
		<td>                                                              <span class="badge badge-success">Active</span></td>
		<td >
		<a href="javascript:" class="my-btn btn-primary"><span class="ti-pencil"></span></a>
	</td>
	</tr>
												   
	<tr>
		
		<td>2</td>
		<td>2019-06-15 22:56:02</td>
		<td>App</td>
		<td>nisha</td>
		<td>9511527869</td>
		<td>qatzt3</td>
		<td>jpw7qz</td>

		<td></td>
		<td>10</td> 
<!--                                                            <td>0</td>-->
		<td>0</td> 
		<td>                                                              <span class="badge badge-success">Active</span></td>
		<td ><a href="javascript:" class="my-btn btn-primary"><span class="ti-pencil"></span></a>
	</td>
	</tr>
												   
	<tr>
		
		<td>3</td>
		<td>2019-06-15 03:14:16</td>
		<td>Web</td>
		<td>Azzazz</td>
		<td>8800660050</td>
		<td>hgoiv3</td>
		<td></td>
		<td></td>
		<td>0</td> 
		<td>0</td> 
		<td><span class="badge badge-danger">Deactive</span></td>
		<td >
		<a href="javascript:" class="my-btn btn-primary"><span class="ti-pencil"></span></a>
	</td>
	</tr>
												   
	<tr>
		
		<td>4</td>
		<td>2019-06-13 21:55:44</td>
		<td>App</td>
		<td>aman</td>
		<td>9999844470</td>
		<td>es1utw</td>
		<td>9mxtgl</td>

		<td></td>
		<td>9</td> 
<!--                                                            <td>0</td>-->
		<td>0</td> 
		<td><span class="badge badge-danger">Deactive</span></td>
		<td >
		<a href="javascript:" class="my-btn btn-primary"><span class="ti-pencil"></span></a>
	</td>
	</tr>
												   
	<tr>
		
		<td>5</td>
		<td>2019-06-13 16:46:37</td>
		<td>App</td>
		<td>Parvez</td>
		<td>9461706885</td>
		<td>qxk462</td>
		<td>rg8jpq</td>

		<td>19</td>
		<td>814</td> 
<!--                                                            <td>0</td>-->
		<td>8480.8</td> 
		<td>                                                              <span class="badge badge-success">Active</span></td>
		<td >
		<a href="javascript:" class="my-btn btn-primary"><span class="ti-pencil"></span></a>
	</td>
	</tr>
												   
	<tr>
		
		<td>6</td>
		<td>2019-06-12 22:35:06</td>
		<td>App</td>
		<td>Deepak</td>
		<td>8058224774</td>
		<td>jpw7qz</td>
		<td></td>

		<td></td>
		<td>10</td> 
<!--                                                            <td>0</td>-->
		<td>0</td> 
		<td>                                                              <span class="badge badge-success">Active</span></td>
		<td >
		<a href="javascript:" class="my-btn btn-primary"><span class="ti-pencil"></span></a>
	</td>
	</tr>
												   
	<tr>
		
		<td>7</td>
		<td>2019-06-12 03:54:17</td>
		<td>App</td>
		<td>Sunil yogi</td>
		<td>8107428896</td>
		<td>pykyqo</td>
		<td></td>

		<td></td>
		<td>0</td> 
<!--                                                            <td>0</td>-->
		<td>0</td> 
		<td>                                                              <span class="badge badge-success">Active</span></td>
		<td >
		<a href="javascript:" class="my-btn btn-primary"><span class="ti-pencil"></span></a>
	</td>
	</tr>
												   
	<tr>
		
		<td>8</td>
		<td>2019-06-11 17:21:03</td>
		<td>App</td>
		<td>Demo</td>
		<td>9602009656</td>
		<td>rg8jpq</td>
		<td></td>

		<td>4</td>
		<td>100</td> 
<!--                                                            <td>0</td>-->
		<td>1684</td> 
		<td>                                                              <span class="badge badge-success">Active</span></td>
		<td >
		<a href="javascript:" class="my-btn btn-primary"><span class="ti-pencil"></span></a>
	</td>
	</tr>
												   
	<tr>
		
		<td>9</td>
		<td>2019-06-08 21:21:24</td>
		<td>App</td>
		<td>Aman</td>
		<td>8585954490</td>
		<td>al5g2s</td>
		<td>8hgbkp</td>

		<td></td>
		<td>10</td> 
<!--                                                            <td>0</td>-->
		<td>0</td> 
		<td><span class="badge badge-danger">Deactive</span></td>
		<td >
		<a href="javascript:" class="my-btn btn-primary"><span class="ti-pencil"></span></a>
	</td>
	</tr>
												   
	<tr>
		
		<td>10</td>
		<td>2019-06-08 21:06:04</td>
		<td>App</td>
		<td>Deepak</td>
		<td>8949260994</td>
		<td>qw05ai</td>
		<td></td>

		<td>3</td>
		<td>90</td> 
<!--                                                            <td>0</td>-->
		<td>7176</td> 
		<td>                                                              <span class="badge badge-success">Active</span></td>
		<td >
		<a href="javascript:" class="my-btn btn-primary"><span class="ti-pencil"></span></a>
	</td>
	</tr>
												   
	<tr>
		
		<td>11</td>
		<td>2019-06-01 20:37:55</td>
		<td>App</td>
		<td>Luvky</td>
		<td>9876543210</td>
		<td>ngbep5</td>
		<td></td>

		<td></td>
		<td>0</td> 
<!--                                                            <td>0</td>-->
		<td>0</td> 
		<td><span class="badge badge-success">Active</span></td>
		<td >
		<a href="javascript:" class="my-btn btn-primary"><span class="ti-pencil"></span></a>
	</td>
	</tr>
												   
	<tr>
		
		<td>12</td>
		<td>2019-06-01 20:37:44</td>
		<td>App</td>
		<td>Luvky</td>
		<td>1234567890</td>
		<td>carzfb</td>
		<td></td>

		<td></td>
		<td>0</td> 
<!--                                                            <td>0</td>-->
		<td>0</td> 
		<td>                                                              <span class="badge badge-success">Active</span></td>
		<td >
		<a href="javascript:" class="my-btn btn-primary"><span class="ti-pencil"></span></a>
	</td>
	</tr>
												   
	<tr>
		
		<td>13</td>
		<td>2019-06-01 00:15:42</td>
		<td>App</td>
		<td>aman</td>
		<td>7240560004</td>
		<td>9mxtgl</td>
		<td></td>

		<td>4</td>
		<td>80</td> 
<!--                                                            <td>0</td>-->
		<td>1813</td> 
		<td>                                                              <span class="badge badge-success">Active</span></td>
		<td >
		<a href="javascript:" class="my-btn btn-primary"><span class="ti-pencil"></span></a>
	</td>
	</tr>
												   
	<tr>
		
		<td>14</td>
		<td>2019-06-01 00:12:38</td>
		<td>App</td>
		<td>shabnam</td>
		<td>8440819805</td>
		<td>8hgbkp</td>
		<td></td>

		<td>3</td>
		<td>0</td> 
<!--                                                            <td>0</td>-->
		<td>5801</td> 
		<td>                                                              <span class="badge badge-success">Active</span></td>
		<td >
		<a href="javascript:" class="my-btn btn-primary"><span class="ti-pencil"></span></a>
	</td>
	</tr>
												   
	<tr>
		
		<td>15</td>
		<td>2019-05-30 17:58:01</td>
		<td>App</td>
		<td>demo</td>
		<td>7240560003</td>
		<td>tda6lv</td>
		<td></td>

		<td>1</td>
		<td>0</td> 
<!--                                                            <td>0</td>-->
		<td>3224</td> 
		<td>                                                              <span class="badge badge-success">Active</span></td>
		<td >
		<a href="javascript:" class="my-btn btn-primary"><span class="ti-pencil"></span></a>
	</td>
	</tr>
												   
	<tr>
		
		<td>16</td>
		<td>2019-05-30 16:46:27</td>
		<td>App</td>
		<td>Lucky</td>
		<td>465465464654</td>
		<td>pm8wb7</td>
		<td></td>

		<td>1</td>
		<td>0</td> 
<!--                                                            <td>0</td>-->
		<td>600.5</td> 
		<td><span class="badge badge-danger">Deactive</span></td>
		<td >
		<a href="javascript:" class="my-btn btn-primary"><span class="ti-pencil"></span></a>
	</td>
	</tr>
												   
	<tr>
		
		<td>17</td>
		<td>2019-05-29 17:40:40</td>
		<td>App</td>
		<td>Parvez</td>
		<td>701456990846546</td>
		<td>3x4804</td>
		<td></td>

		<td>6</td>
		<td>0</td> 
<!--                                                            <td>1</td>-->
		<td>2967</td> 
		<td><span class="badge badge-danger">Deactive</span></td>
		<td >
		<a href="javascript:" class="my-btn btn-primary"><span class="ti-pencil"></span></a>
	</td>
	</tr>
												   
	<tr>
		
		<td>18</td>
		<td>2019-05-29 16:40:38</td>
		<td>App</td>
		<td>Parvez Hafeez</td>
		<td>11545654</td>
		<td>2oit7k</td>
		<td></td>

		<td>6</td>
		<td>0</td> 
<!--                                                            <td>0</td>-->
		<td>5104</td> 
		<td><span class="badge badge-danger">Deactive</span></td>
		<td >
		<a href="javascript:" class="my-btn btn-primary"><span class="ti-pencil"></span></a>
	</td>
	</tr>
											</tbody>

