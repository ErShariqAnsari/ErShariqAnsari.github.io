<thead>
<tr>
	<th>ID</th>
	<th>City Name :</th>	
	<th>Action</th>
</tr>
</thead>
<tbody>
<tr>
<td>1</td>
<td>Chhawani</td>
<td><div class="btn-group">
	<div class="btn-group">
		<a href="javascript:" class="my-btn btn-primary" data-toggle="modal" data-target="#myCity">
		<span class="ti-pencil"></span></a>&nbsp;
		<a href="javascript:" class="my-btn btn-danger">
		<span class="ti-trash"></span></a>                                                            
	</div>
</td>
</tr>
<tr>
<td>2</td>
<td>Gumanpura-Kota</td>
<td>
	<div class="btn-group">
		<a href="javascript:" class="my-btn btn-primary" data-toggle="modal" data-target="#myCity">
		<span class="ti-pencil"></span></a>&nbsp;
		<a href="javascript:" class="my-btn btn-danger">
		<span class="ti-trash"></span></a>                                                            
	</div>
</td>
</tr>
<tr>
<td>3</td>
<td>Mahaveer Nagar</td>
<td>
	<div class="btn-group">
		<a href="javascript:" class="my-btn btn-primary" data-toggle="modal" data-target="#myCity">
		<span class="ti-pencil"></span></a>&nbsp;
		<a href="javascript:" class="my-btn btn-danger">
		<span class="ti-trash"></span></a>                                                            
	</div>
</td>
</tr>
<tr>
<td>4</td>
<td>saraswati colony Police line</td>
<td>
	<div class="btn-group">
		<a href="javascript:" class="my-btn btn-primary" data-toggle="modal" data-target="#myCity">
		<span class="ti-pencil"></span></a>&nbsp;
		<a href="javascript:" class="my-btn btn-danger">
		<span class="ti-trash"></span></a>                                                            
	</div>
</td>
</tr>  
</tbody>