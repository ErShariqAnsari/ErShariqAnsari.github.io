<thead>
	<tr>
		<th>ID</th>
		<th>Product Name</th>
		<th>Cat Name</th>
		<th>Product Description</th>
		<th>Image</th>
		<th>Prices</th>
		<th>Status</th>	
		<th>Action</th>
	</tr>
</thead>
<tbody>
	<tr>
		<td>1</td>
		<td>Fem Fairness Naturals Creme Bleach - ( Gold - 24 gm )</td> 
		<td>Facial Kit & Bleach</td>
		<td>
		Fem Fairness Naturals  Gold Creme Bleach,<br/>
		For Special Occasions, <br/>
		Net wt : 24 Gm, <br/>
		Price Per Packet : 57 Rs., <br/>
		Your Saving : 8 Rs., <br/>
		Off : 12.30 %, <br/>
		3 Uses , No Added Ammonia
		</td>
		<td>
		<div class="cat-img">
		<img src="http://localhost/bloomkart/backend/uploads/products/1557389231-h-250-fem-fairness-naturals-gold-creme-bleach-64gm-5.jpg" class="img-responsive" style="max-height:55px;" />
		</div></td>
		<td>57 per 1Kit</td>
		<td><span class="badge badge-success">In Stock</span></td>
		<td><div class="btn-group">
		<a href="product/add-product.php" class="my-btn btn-primary">
		<span class="ti-pencil"></span></a>&nbsp;
		<a href="javascript:" class="my-btn btn-danger">
		<span class="ti-trash"></span></a>                                                            
		</div></td>
	</tr>
	<tr>
		<td>2</td>
		<td>Fem Fairness Naturals Creme Bleach - ( Gold - 24 gm )</td> 
		<td>Facial Kit & Bleach</td>
		<td>
		Fem Fairness Naturals  Gold Creme Bleach,<br/>
		For Special Occasions, <br/>
		Net wt : 24 Gm, <br/>
		Price Per Packet : 57 Rs., <br/>
		Your Saving : 8 Rs., <br/>
		Off : 12.30 %, <br/>
		3 Uses , No Added Ammonia
		</td>
		<td>
		<div class="cat-img">
		<img src="http://localhost/bloomkart/backend/uploads/products/1557389231-h-250-fem-fairness-naturals-gold-creme-bleach-64gm-5.jpg" class="img-responsive" style="max-height:55px;" />
		</div></td>
		<td>57 per 1Kit</td>
		<td><span class="badge badge-success">In Stock</span></td>
		<td><div class="btn-group">
		<a href="product/add-product.php" class="my-btn btn-primary">
		<span class="ti-pencil"></span></a>&nbsp;
		<a href="javascript:" class="my-btn btn-danger">
		<span class="ti-trash"></span></a>                                                            
		</div></td>
	</tr>
	<tr>
		<td>3</td>
		<td>Fem Fairness Naturals Creme Bleach - ( Gold - 24 gm )</td> 
		<td>Facial Kit & Bleach</td>
		<td>
		Fem Fairness Naturals  Gold Creme Bleach,<br/>
		For Special Occasions, <br/>
		Net wt : 24 Gm, <br/>
		Price Per Packet : 57 Rs., <br/>
		Your Saving : 8 Rs., <br/>
		Off : 12.30 %, <br/>
		3 Uses , No Added Ammonia
		</td>
		<td>
		<div class="cat-img">
		<img src="http://localhost/bloomkart/backend/uploads/products/1557389231-h-250-fem-fairness-naturals-gold-creme-bleach-64gm-5.jpg" class="img-responsive" style="max-height:55px;" />
		</div></td>
		<td>57 per 1Kit</td>
		<td><span class="badge badge-danger">Out of Stock</span></td>
		<td><div class="btn-group">
		<a href="product/add-product.php" class="my-btn btn-primary">
		<span class="ti-pencil"></span></a>&nbsp;
		<a href="javascript:" class="my-btn btn-danger">
		<span class="ti-trash"></span></a>                                                            
		</div></td>
	</tr>
</tbody>