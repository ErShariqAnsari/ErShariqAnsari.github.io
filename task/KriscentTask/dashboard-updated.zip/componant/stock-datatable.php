<thead>
<tr>
	<th>ID</th>
	<th>Title</th>
	<th>Unit</th>
	<th>Stock</th>
	<th>Action</th>
</tr>
</thead>
<tbody>
<tr>
	<td>1</td>
	<td>Fem Fairness Naturals Creme Bleach - ( Gold - 24 gm )</td>
	<td>Kit</td> 
	<td>15</td>  
	<td>
         <div class="btn-group">
            <a href="javascript:" class="my-btn btn-primary" data-toggle="modal" data-target="#myEditStock">
			<span class="ti-pencil"></span></a>&nbsp;
            <a href="javascript:" class="my-btn btn-danger">
            <span class="ti-trash"></span></a>                                                            
         </div>
      </td>
	
</tr>
<tr>
	<td>2</td>
	<td>Cherry Blossom Shoe Polish - ( Black - 40 gm )</td>
	<td>Pack</td> 
	<td>1</td>
	<td>
         <div class="btn-group">
            <a href="javascript:" class="my-btn btn-primary" data-toggle="modal" data-target="#myEditStock">
			<span class="ti-pencil"></span></a>&nbsp;
            <a href="javascript:" class="my-btn btn-danger">
            <span class="ti-trash"></span></a>                                                            
         </div>
      </td>
	
	
</tr>
<tr>
	<td>3</td>
	<td>Cherry Blossom Shoe Polish - ( Black - 15 gm )</td>
	<td>Pack</td> 
	<td>2</td>
	<td>
         <div class="btn-group">
            <a href="javascript:" class="my-btn btn-primary" data-toggle="modal" data-target="#myEditStock">
			<span class="ti-pencil"></span></a>&nbsp;
            <a href="javascript:" class="my-btn btn-danger">
            <span class="ti-trash"></span></a>                                                            
         </div>
      </td>	
	
</tr>
<tr>
	<td>4</td>
	<td>Cherry Liquid Canvas Shoe Cleaner - ( White - 75 ml )</td>
	<td>Piece</td> 
	<td>1</td>
	<td>
         <div class="btn-group">
            <a href="javascript:" class="my-btn btn-primary" data-toggle="modal" data-target="#myEditStock">
			<span class="ti-pencil"></span></a>&nbsp;
            <a href="javascript:" class="my-btn btn-danger">
            <span class="ti-trash"></span></a>                                                            
         </div>
      </td>
	
</tr>
<tr>
	<td>5</td>
	<td>Parle Krack Jack Biscuit </td>
	<td>Pack</td> 
	<td>100</td>
	<td>
         <div class="btn-group">
            <a href="javascript:" class="my-btn btn-primary" data-toggle="modal" data-target="#myEditStock">
			<span class="ti-pencil"></span></a>&nbsp;
            <a href="javascript:" class="my-btn btn-danger">
            <span class="ti-trash"></span></a>                                                            
         </div>
      </td>
	
</tr>
<tr>
	<td>6</td>
	<td>Mirinda - ( Orange - 2.25 Lit. )</td>
	<td>Bottle</td> 
	<td>1</td>  
	<td>
         <div class="btn-group">
            <a href="javascript:" class="my-btn btn-primary" data-toggle="modal" data-target="#myEditStock">
			<span class="ti-pencil"></span></a>&nbsp;
            <a href="javascript:" class="my-btn btn-danger">
            <span class="ti-trash"></span></a>                                                            
         </div>
      </td>
	
</tr>
<tr>
	<td>7</td>
	<td>Mirinda - ( Orange - 750 ml )</td>
	<td>Bottle</td> 
	<td>2</td>  
	<td>
         <div class="btn-group">
            <a href="javascript:" class="my-btn btn-primary" data-toggle="modal" data-target="#myEditStock">
			<span class="ti-pencil"></span></a>&nbsp;
            <a href="javascript:" class="my-btn btn-danger">
            <span class="ti-trash"></span></a>                                                            
         </div>
      </td>
	
</tr>  
</tbody>