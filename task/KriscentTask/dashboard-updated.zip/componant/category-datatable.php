<thead>
<tr>
<th>Cat ID</th>
<th>Cat Name</th>
<th>Parent Category</th>
<th>Image</th>
<th>Status</th>
<th>Action</th>
</tr>
</thead>
<tbody>
   <tr>
      <td>9</td>
      <td>Patanjali</td>
      <td>Grocery</td>
      <td>
         <div class="cat-img">
		 <img src="http://localhost/bloomkart/backend/uploads/category/1551179531-h-150-031.jpg" class="img-responsive" style="max-height:55px;" />
		 </div>
      </td>
      <td><span class="badge badge-success"> Active</span></td>
      <td>
         <div class="btn-group">
            <a href="javascript:" class="my-btn btn-primary">
			<span class="ti-pencil"></span></a>&nbsp;
            <a href="javascript:" class="my-btn btn-danger">
            <span class="ti-trash"></span></a>                                                            
         </div>
      </td>
   </tr>   
</tbody>