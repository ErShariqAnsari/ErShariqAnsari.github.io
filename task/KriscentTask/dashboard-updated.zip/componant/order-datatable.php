<thead>
   <tr>
      <th class="text-center">Order</th>
      <th class="text-center">Created At</th>
      <th class="text-center">Order By</th>
      <th class="text-center">Customer Name</th>
      <th class="text-center">Delivery Date</th>
      <th class="text-center">Mobile No. </th>
      <th class="text-center">Order Amount</th>
      <th class="text-center">Payment Method</th>
      <th class="text-center">Status</th>
      <th class="text-center">Action</th>
   </tr>
</thead>
<tbody>
   <tr>
      <td>1</td>
      <td>2019-06-23 00:40:48</td>
      <td>Web</td>
      <td>Deepak</td>
      <td>2019-06-23 05:30 AM - 05:30 AM                                                            
      </td>
      <!--                                                            <td>--><!--</td>-->
      <td>8949260994</td>
      <!--<td>05:30 AM - 05:30 AM</td>-->
      <td>473</td>
      <!--                                                            <td>--><!--</td>-->
      <!--                                                            <td>--><!--</td>-->
      <td>Cash On Delivery</td>
      <td><span class='badge badge-success'>Confirm</span>                                                            </td>
      <td>
         <a href="javascript:" class="my-btn btn-primary" title="Order Details"> 
         <span class="ti-info"></span></a>
         <div class="dropdown d-inline-block">
            <a class="my-btn btn-danger dropdown-toggle text-white " data-toggle="dropdown" title="More Actions">
			<span class="ti-pencil-alt"></span></a>
            <ul class="dropdown-menu dropdown-menu-right f-14px">
               <li><a class="dropdown-item" href="javascript:"><span class="ti-close"></span>&nbsp;&nbsp; Cancel</a></li>
               <li><a class="dropdown-item" href="javascript:"><span class="ti-check"></span>&nbsp;&nbsp; Confirm</a></li>
               <li><a class="dropdown-item" href="javascript:"><span class="ti-trash"></span>&nbsp;&nbsp; Delete</a></li>
            </ul>
         </div>
      </td>
   </tr>
   <tr>
      <td>2</td>
      <td>2019-06-22 17:24:16</td>
      <td>Web</td>
      <td>shabnam</td>
      <td>2019-06-22 05:30 AM - 05:30 AM                                                            
      </td>
      <!--                                                            <td>--><!--</td>-->
      <td>8440819805</td>
      <!--<td>05:30 AM - 05:30 AM</td>-->
      <td>342</td>
      <!--                                                            <td>--><!--</td>-->
      <!--                                                            <td>--><!--</td>-->
      <td>Cash On Delivery</td>
      <td><span class='badge badge-info'>Pending</span>                                                            </td>
      <td>
         <a href="javascript:" class="my-btn btn-primary" title="Order Details"> 
         <span class="ti-info"></span></a>
         <div class="dropdown d-inline-block">
            <a class="my-btn btn-danger dropdown-toggle text-white " data-toggle="dropdown" title="More Actions">
			<span class="ti-pencil-alt"></span></a>
            <ul class="dropdown-menu dropdown-menu-right f-14px">
               <li><a class="dropdown-item" href="javascript:"><span class="ti-close"></span>&nbsp;&nbsp; Cancel</a></li>
               <li><a class="dropdown-item" href="javascript:"><span class="ti-check"></span>&nbsp;&nbsp; Confirm</a></li>
               <li><a class="dropdown-item" href="javascript:"><span class="ti-trash"></span>&nbsp;&nbsp; Delete</a></li>
            </ul>
         </div>
      </td>
   </tr>
   <tr>
      <td>3</td>
      <td>2019-06-21 23:05:24</td>
      <td>Web</td>
      <td>aman</td>
      <td>2019-06-21 05:30 AM - 05:30 AM                                                            
      </td>
      <!--                                                            <td>--><!--</td>-->
      <td>7240560004</td>
      <!--<td>05:30 AM - 05:30 AM</td>-->
      <td>560</td>
      <!--                                                            <td>--><!--</td>-->
      <!--                                                            <td>--><!--</td>-->
      <td>Cash On Delivery</td>
      <td><span class='badge badge-danger'>Cancel</span>                                                            </td>
      <td>
         <a href="javascript:" class="my-btn btn-primary" title="Order Details"> 
         <span class="ti-info"></span></a>
         <div class="dropdown d-inline-block">
            <a class="my-btn btn-danger dropdown-toggle text-white " data-toggle="dropdown" title="More Actions">
			<span class="ti-pencil-alt"></span></a>
            <ul class="dropdown-menu dropdown-menu-right f-14px">
               <li><a class="dropdown-item" href="javascript:"><span class="ti-close"></span>&nbsp;&nbsp; Cancel</a></li>
               <li><a class="dropdown-item" href="javascript:"><span class="ti-check"></span>&nbsp;&nbsp; Confirm</a></li>
               <li><a class="dropdown-item" href="javascript:"><span class="ti-trash"></span>&nbsp;&nbsp; Delete</a></li>
            </ul>
         </div>
      </td>
   </tr>
   <tr>
      <td>4</td>
      <td>2019-06-19 19:30:45</td>
      <td>Web</td>
      <td>shabnam</td>
      <td>2019-06-19 05:30 AM - 05:30 AM </td>      
      <td>8440819805</td>      
      <td>595</td>      
      <td>Cash On Delivery</td>
      <td><span class='badge badge-info'>Pending</span></td>
      <td>
         <a href="javascript:" class="my-btn btn-primary" title="Order Details"> 
         <span class="ti-info"></span></a>
         <div class="dropdown d-inline-block">
            <a class="my-btn btn-danger dropdown-toggle text-white " data-toggle="dropdown" title="More Actions">
			<span class="ti-pencil-alt"></span></a>
            <ul class="dropdown-menu dropdown-menu-right f-14px">
               <li><a class="dropdown-item" href="javascript:"><span class="ti-close"></span>&nbsp;&nbsp; Cancel</a></li>
               <li><a class="dropdown-item" href="javascript:"><span class="ti-check"></span>&nbsp;&nbsp; Confirm</a></li>
               <li><a class="dropdown-item" href="javascript:"><span class="ti-trash"></span>&nbsp;&nbsp; Delete</a></li>
            </ul>
         </div>
      </td>
   </tr>
   
</tbody>