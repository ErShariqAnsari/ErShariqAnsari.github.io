<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Kriscent Admin Dashboard</title>
<meta name="description" content="">
<meta name="google-site-verification" content="" />

<?php $baseurl = 'http://'.$_SERVER['SERVER_NAME'].'/projects/MyDesign/dashboard/Kriscent/' ?>

<link rel="shortcut icon" href="<?php echo $baseurl; ?>assets/images/favicon.png" />      
<link rel="stylesheet" href="<?php echo $baseurl; ?>assets/css/bootstrap.min.css" />
<link rel="stylesheet" href="<?php echo $baseurl; ?>assets/css/font-awesome.min.css" />
<link rel="stylesheet" href="<?php echo $baseurl; ?>assets/css/themify-icons.css" />
<link rel="stylesheet" href="<?php echo $baseurl; ?>assets/css/dataTables.bootstrap4.css"/>
<link rel="stylesheet" href="<?php echo $baseurl; ?>assets/css/gijgo.min.css" />
<link rel="stylesheet" href="<?php echo $baseurl; ?>assets/css/hover.css" />
<link rel="stylesheet" href="<?php echo $baseurl; ?>assets/css/animate.css" />
<link rel="stylesheet" href="<?php echo $baseurl; ?>assets/css/common.css" />
<link rel="stylesheet" href="<?php echo $baseurl; ?>assets/css/dashboard.css" />

<!-- Load c3.css -->
<link href="<?php echo $baseurl; ?>assets/css/c3.css" rel="stylesheet">


</head>

<body>
<!-- Header -->
<header id="header" class="">
  <!--Headerbar Start-->
  <nav class="navbar navbar-expand-md nav-header">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link open-close" href="javascript:">
          <span class="ti-align-left"></span>&nbsp;&nbsp;&nbsp; Dashboard
        </a>
      </li>    
    </ul>

    <ul class="nav ml-auto align-items-center">
      <li class="nav-item dropdown notification-drop-area">
        <a class="nav-link" href="javascript:" data-toggle="dropdown">
          <span class="ti-bell"></span>
        </a>
        <div class="dropdown-menu dropdown-menu-right">
          <div class="notifications-box" id="notificationsBox">
            <a href="#" class="dropdown-item"><i class="ti-face-smile bg-success"></i><span>We've got something for you!</span></a>
            <a href="#" class="dropdown-item"><i class="ti-bell bg-danger"></i><span>Domain names expiring on Tuesday</span></a>
            <a href="#" class="dropdown-item"><i class="ti-check bg-primary"></i><span>Your commissions has been sent</span></a>
            <a href="#" class="dropdown-item"><i class="ti-heart bg-success"></i><span>You sold an item!</span></a>
            <a href="#" class="dropdown-item"><i class="ti-bolt bg-warning"></i><span>Security alert for your linked Google account</span></a>
            <a href="#" class="dropdown-item"><i class="ti-face-smile bg-success"></i><span>We've got something for you!</span></a>
            <a href="#" class="dropdown-item"><i class="ti-bell bg-danger"></i><span>Domain names expiring on Tuesday</span></a>
            <a href="#" class="dropdown-item"><i class="ti-check bg-primary"></i><span>Your commissions has been sent</span></a>
            <a href="#" class="dropdown-item"><i class="ti-heart bg-success"></i><span>You sold an item!</span></a>
            <a href="#" class="dropdown-item"><i class="ti-bolt bg-warning"></i><span>Security alert for your linked Google account</span></a>
          </div>
        </div>
      </li>
         
      <li class="nav-item dropdown user-profile-area">
        <a class="nav-link" href="javascript:" data-toggle="dropdown">
          <img src="<?php echo $baseurl; ?>assets/images/pic1.png" class="img-fluid" style="max-height: 40px;" />
        </a>
        <div class="dropdown-menu dropdown-menu-right">
          <a class="dropdown-item" href="javascript:">
            <span class="ti-user"></span>&nbsp;&nbsp;&nbsp; My Profile
          </a>
          <a class="dropdown-item" href="javascript:">
            <span class="ti-settings"></span>&nbsp;&nbsp;&nbsp; Acount Setting
          </a>
          <a class="dropdown-item" href="javascript:">
            <span class="ti-power-off"></span>&nbsp;&nbsp;&nbsp; Logout
          </a>
        </div>
      </li>
    </ul>
  </nav>
  <div style="height: 55px;"></div>
  <!--Headerbar Start End-->

  <!--SideBar Start-->
  <div class="sidebar openbar" id="mySideBar">
    <div class="logo-head d-flex align-items-center">
      <span class="logo-icon">
        <img src="<?php echo $baseurl; ?>assets/images/logo.png" class="img-fluid" style="max-height: 55px;" />
      </span>    
    </div>
    <ul id="ulnav-scroll" class="nav flex-column flex-nowrap">
      <li class="nav-item head-nav"><a class="nav-link" href="<?php echo $baseurl; ?>">
      <span class="ti-layout-grid2 side-icon"></span>
      <span class="side-name">Dashboard</span></a></li>

      <li class="nav-item head-nav"><a class="nav-link" href="<?php echo $baseurl; ?>app-user.php">
      <span class="ti-mobile side-icon"></span>
      <span class="side-name">App User</span></a></li>

      <li class="nav-item head-nav"><a class="nav-link" href="<?php echo $baseurl; ?>order.php">
      <span class="ti-shopping-cart side-icon"></span>
      <span class="side-name">Order</span></a></li>

      <li class="nav-item head-nav"><a class="nav-link" href="<?php echo $baseurl; ?>category.php">
      <span class="ti-server side-icon"></span>
      <span class="side-name">Category</span></a></li>

      <li class="nav-item head-nav"><a class="nav-link" href="<?php echo $baseurl; ?>product.php">
      <span class="ti-dropbox side-icon"></span>
      <span class="side-name">Products</span></a></li>

      <li class="nav-item head-nav"><a class="nav-link" href="<?php echo $baseurl; ?>stock.php">
      <span class="ti-package side-icon"></span>
      <span class="side-name">Stocks</span></a></li>      

      <li class="nav-item head-nav"><a class="nav-link" href="<?php echo $baseurl; ?>society.php">
      <span class="ti-user side-icon"></span>
      <span class="side-name">Society</span></a></li>

      <li class="nav-item head-nav"><a class="nav-link" href="<?php echo $baseurl; ?>city.php">
      <span class="ti-location-arrow side-icon"></span>
      <span class="side-name">City</span></a></li>

      <li class="nav-item head-nav">
          <a class="nav-link collapsed" href="#submenu1" data-toggle="collapse" data-target="#submenu1">
            <span class="ti-truck side-icon"></span> 
            <span class="side-name">Delivery</span></a>
          <div class="collapse" id="submenu1" aria-expanded="false">
              <ul class="flex-column pl-2 nav bg-grey">
                  <li class="nav-item"><a class="nav-link" href="javascript:">
                  <i class="fa fa-circle mr-2"></i>Time Slot</a></li>
                  <li class="nav-item"><a class="nav-link" href="javascript:">
                  <i class="fa fa-circle mr-2"></i>Closing Hours</a></li>                
              </ul>
          </div>
      </li>

      <li class="nav-item head-nav">
          <a class="nav-link collapsed" href="#submenu2" data-toggle="collapse" data-target="#submenu2">
            <span class="ti-files side-icon"></span> 
            <span class="side-name">Legel Pages</span></a>
          <div class="collapse" id="submenu2" aria-expanded="false">
              <ul class="flex-column pl-2 nav bg-grey">
                  <li class="nav-item"><a class="nav-link" href="javascript:">
                  <i class="fa fa-circle mr-2"></i>All Pages</a></li>                               
              </ul>
          </div>
      </li>

      <li class="nav-item head-nav">
          <a class="nav-link collapsed" href="#submenu3" data-toggle="collapse" data-target="#submenu3">
            <span class="ti-gallery side-icon"></span> 
            <span class="side-name">Slider</span></a>
          <div class="collapse" id="submenu3" aria-expanded="false">
              <ul class="flex-column pl-2 nav bg-grey">
                  <li class="nav-item"><a class="nav-link" href="javascript:">
                  <i class="fa fa-circle mr-2"></i>Main Slider</a></li> 
                  <li class="nav-item"><a class="nav-link" href="javascript:">
                  <i class="fa fa-circle mr-2"></i>Secondary Slider</a></li>
                  <li class="nav-item"><a class="nav-link" href="javascript:">
                  <i class="fa fa-circle mr-2"></i>Feature Slider</a></li>                              
              </ul>
          </div>
      </li>


      <li class="nav-item head-nav">
          <a class="nav-link collapsed" href="#multi-submenu1" data-toggle="collapse" data-target="#multi-submenu1">
            <span class="ti-bar-chart side-icon"></span> 
            <span class="side-name">Component</span></a>
          <div class="collapse" id="multi-submenu1" aria-expanded="false">
              <ul class="flex-column pl-2 nav bg-grey">
                  <li class="nav-item"><a class="nav-link" href="chart.php">
                  <i class="fa fa-circle mr-2"></i>C3 Chart</a></li>
                  <li class="nav-item"><a class="nav-link" href="table.php">
                  <i class="fa fa-circle mr-2"></i>Table</a></li>                  
                  <li class="nav-item">
                      <a class="nav-link collapsed" href="#multi-submenu1sub1" data-toggle="collapse" data-target="#multi-submenu1sub1">
                        <i class="fa fa-circle mr-2"></i> Customers</a>
                      <div class="collapse" id="multi-submenu1sub1" aria-expanded="false">
                          <ul class="flex-column nav pl-2">
                              <li class="nav-item">
                                  <a class="nav-link" href="#">
                                      <i class="fa fa-minus mr-2"></i> Daily
                                  </a>
                              </li>
                              <li class="nav-item">
                                  <a class="nav-link" href="#">
                                      <i class="fa fa-minus mr-2"></i> Dashboard
                                  </a>
                              </li>
                              <li class="nav-item">
                                  <a class="nav-link" href="#">
                                      <i class="fa fa-minus mr-2"></i> Charts
                                  </a>
                              </li>
                              <li class="nav-item">
                                  <a class="nav-link" href="#">
                                      <i class="fa fa-minus mr-2"></i> Areas
                                  </a>
                              </li>
                          </ul>
                      </div>
                  </li>
              </ul>
          </div>
      </li>
      
      <li class="nav-item head-nav"><a class="nav-link" href="javascript:">
        <span class="ti-image side-icon"></span><span class="side-name">Analytics</span></a>
      </li>
      <li class="nav-item head-nav"><a class="nav-link" href="javascript:">
        <span class="ti-export side-icon"></span><span class="side-name">Export</a></span></li>
  </ul>
  </div><!--End Side Navbar-->
</header>
<!-- /header -->





