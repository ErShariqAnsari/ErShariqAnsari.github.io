
<?php include('header.php'); ?>


<!-- Content Section -->
<section id="MainContentBlock" class="ContentBlock">
	<div class="container-fluid p-3 p-lg-4">
		<div class="row">
			<div class="col-12">
				<h4>Hello <span class="text-theme-clr">Shariq</span>, Welcome to Dashboard</h4>
				<p>Here you can manage your front end ecommerce shop</p>
			</div>
		</div>

		<div class="row mt-3 mt-lg-4">			
			<div class="col-12 col-md-3">
				<div class="bg-light p-3 p-lg-4">					
					<div class="media">
					  <span class="ti-shopping-cart-full f-48px"></span>
					  <div class="media-body ml-3 ml-lg-4">
					    <h6>Daily Order</h6>	
					    <p class="f-20px w300">
					    	<span class="text-theme-clr">1000+</span></p>		    
					  </div>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-3">
				<div class="bg-light p-3 p-lg-4">					
					<div class="media">
					  <span class="ti-user f-48px"></span>
					  <div class="media-body ml-3 ml-lg-4">
					    <h6>Active Users</h6>	
					    <p class="f-20px w300">
					    	<span class="text-theme-clr">1100+</span></p>		    
					  </div>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-3">
				<div class="bg-light p-3 p-lg-4">					
					<div class="media">
					  <span class="ti-bar-chart-alt f-48px"></span>
					  <div class="media-body ml-3 ml-lg-4">
					    <h6>Total Sales</h6>	
					    <p class="f-20px w300">
					    	<span class="text-theme-clr">1500+</span></p>		    
					  </div>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-3">
				<div class="bg-light p-3 p-lg-4">					
					<div class="media">
					  <span class="ti-money f-48px"></span>
					  <div class="media-body ml-3 ml-lg-4">
					    <h6>Total Revenue</h6>	
					    <p class="f-20px w300">
					    	<span class="text-theme-clr">150000+</span></p>		    
					  </div>
					</div>
				</div>
			</div>
		</div>

		<div class="row mt-3 mt-lg-4">			
			<div class="col-12">
				<div class="bg-light p-3 p-lg-4">
					<h4 class="mb-3">Today Order</h4>
					<div class="table-responsive">
						<table id="datatable1" class="table table-striped table-bordered w-100">
						<?php include('componant/datatable.php'); ?>
						</table>
					</div>
				</div>
			</div>
		</div>

		<div class="row mt-3 mt-lg-4">			
			<div class="col-12">
				<div class="bg-light p-3 p-lg-4">
					<h4 class="mb-3">Next Day Order</h4>
					<div class="table-responsive">
						<table id="datatable2" class="table table-striped table-bordered w-100">
						<?php include('componant/datatable.php'); ?>
						</table>
					</div>
				</div>
			</div>
		</div>

	</div>
</section>
<!-- Content Section End-->


<?php include('footer.php'); ?>


