
<?php include('header.php'); ?>


<!-- Content Section -->
<section id="MainContentBlock" class="ContentBlock">
	<div class="container-fluid p-3 p-lg-4">
		<div class="row">
			<div class="col-12">
				<h4>Hello <span class="text-theme-clr">Shariq</span>, Welcome to Dashboard</h4>
				<p>Here you can manage your front end ecommerce shop</p>
			</div>
		</div>

		<div class="row mt-3 mt-lg-4">			
			<div class="col-12">
				<div class="bg-light p-3">
					<h4 class="mb-3">Normal Responsive Table:</h4>
					<div class="table-responsive">
					  <table class="table table-bordered">
					      <thead>
					        <tr>
					          <th>#</th>
					          <th>Firstname</th>
					          <th>Lastname</th>
					          <th>Age</th>
					          <th>City</th>
					          <th>Country</th>
					          <th>Sex</th>
					          <th>Example</th>
					          <th>Example</th>
					          <th>Example</th>
					          <th>Example</th>
					          <th>Example</th>
					          <th>Example</th>
					          <th>Example</th>
					          <th>Example</th>
					          <th>Example</th>
					          <th>Example</th>
					          <th>Example</th>
					          <th>Example</th>
					        </tr>
					      </thead>
					      <tbody>
					        <tr>
					          <td>1</td>
					          <td>Anna</td>
					          <td>Pitt</td>
					          <td>35</td>
					          <td>New York</td>
					          <td>USA</td>
					          <td>Female</td>
					          <td>Yes</td>
					          <td>Yes</td>
					          <td>Yes</td>
					          <td>Yes</td>
					          <td>Yes</td>
					          <td>Yes</td>
					          <td>Yes</td>
					          <td>Yes</td>
					          <td>Yes</td>
					          <td>Yes</td>
					          <td>Yes</td>
					          <td>Yes</td>
					        </tr>
					      </tbody>
					    </table>
					</div>
				</div>
			</div>
		</div>

		<div class="row mt-3 mt-lg-4">			
			<div class="col-12">
				<div class="bg-light p-3">
					<h4 class="mb-3">Normal Responsive Table:</h4>
					<div class="table-responsive">
						<table id="datatable1" class="table table-striped table-bordered w-100">
						  <?php include('componant/datatable.php'); ?>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Content Section End-->


<?php include('footer.php'); ?>


