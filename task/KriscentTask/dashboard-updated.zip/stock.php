
<?php include('header.php'); ?>


<!-- Content Section -->
<section id="MainContentBlock" class="ContentBlock">
	<div class="container-fluid p-3 p-lg-4">
		<div class="row">
			<div class="col-12">
				<h4>All Stock</h4>
				<p>Here you can manage your front end ecommerce shop</p>
			</div>			
		</div>		

		<div class="row mt-3 mt-lg-4">			
			<div class="col-12">
				<div class="bg-light p-3 p-lg-4">					
					<div class="table-responsive">
						<table id="datatable1" class="table table-striped table-bordered w-100">
						<?php include('componant/stock-datatable.php'); ?>
						</table>
					</div>
				</div>
			</div>
		</div>		

	</div>
</section>
<!-- Content Section End-->


<?php include('footer.php'); ?>


