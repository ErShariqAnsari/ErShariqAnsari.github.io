
<?php include('../header.php'); ?>


<!-- Content Section -->
<section id="MainContentBlock" class="ContentBlock">
	<div class="container-fluid p-3 p-lg-4">				

		<div class="row">			
			<div class="col-12">
				<div class="bg-light p-3 p-lg-4">
					<h4 class="mb-3">Add New Category</h4>
					<form>
					  <div class="form-group row">
					    <label for="CategoriesTitle" class="col-md-2 col-form-label">
					    	Categories Title <span class="text-danger">*</span>
					    </label>
					    <div class="col-md-10">
					      <input type="text" class="my-input" id="CategoriesTitle" value="Baby Care" placeholder="Categories Title" />
					    </div>
					  </div>
					  <div class="form-group row">
					    <label for="ParentCategory" class="col-md-2 col-form-label">
					    Parent Category <span class="text-danger">*</span></label>
					    <div class="col-md-10">
					      <select id="select-dropdown">
					      	<option value="no">No Parent</option>
					      	<option value="1">Category #1</option>
					      	<option value="2">Category #2</option>
					      	<option value="3">Category #3</option>		      	
					      </select>
					    </div>
					  </div>
					  <div class="form-group row">
					    <label class="col-md-2 col-form-label">
					    Choose Image </label>
					    <div class="col-md-10">
					    	<div class="media">
					    	<div class="category-img d-flex align-items-center">
					    		<img src="<?php echo $baseurl; ?>assets/images/logo.png" alt="" class="img-fluid mx-auto">
					    	</div>
					    	<div class="media-body align-self-center ml-3 ml-md-4">
					    	<label class="my-btn btn-theme-clr mt-3">
		                        <i class="ti-pencil-alt"></i>
		                        <input type="file" class="d-none" /> Browse
		                    </label></div>
		                    </div>					    	
					    </div>
					  </div>

					  <div class="form-group row">
					  	  <label class="col-md-2 col-form-label">
					      Status <span class="text-danger">*</span></label>
					    <div class="col-md-10 d-flex align-self-center">
						  <div class="radio radio-primary pl-0">
	                        <input type="radio" name="radio1" id="radio1" value="option1" checked="">
	                        <label for="radio1">
	                            Active
	                        </label>
	                      </div>
	                      <div class="radio radio-primary">
	                        <input type="radio" name="radio1" id="radio2" value="option1">
	                        <label for="radio2">
	                            Deactive
	                        </label>
	                      </div>
	                  	</div>
	                  </div>

	                  <div class="form-group row">
	                  	<div class="col-md-2"></div>
	                  	<div class="col-md-10">
	                  		<button type="button" class="my-btn btn-theme-clr">
		                         Add Category
		                    </button>
	                  	</div>
	                  </div>
					</form>
				</div>
			</div>
		</div>

	</div>
</section>
<!-- Content Section End-->


<?php include('../footer.php'); ?>


