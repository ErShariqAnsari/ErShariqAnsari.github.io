
<?php include('header.php'); ?>


<!-- Content Section -->
<section id="MainContentBlock" class="ContentBlock">
	<div class="container-fluid p-3 p-lg-4">
		<div class="row">
			<div class="col-12">
				<h4>C3 Chart Demo</h4>
				<p>Here you can manage your front end ecommerce shop</p>
			</div>
		</div>

		<div class="row mt-3 mt-lg-4">
			<div class="col-12">
				<div class="bg-light p-3 p-lg-4">
					<h3>Line Chart</h3>
					<div id="chart"></div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-12 col-md-6 mt-3 mt-lg-4">
				<div class="bg-light p-3 p-lg-4">
					<h3>Donut Chart</h3>
					<div id="chart_donut"></div>
				</div>
			</div>
			<div class="col-12 col-md-6 mt-3 mt-lg-4">
				<div class="bg-light p-3 p-lg-4">
					<h3>Pie Chart</h3>
					<div id="chart_pie"></div>
				</div>
			</div>
		</div>

	</div>
</section>
<!-- Content Section End-->


<?php include('footer.php'); ?>


