<!-- Footer -->
<footer id="footer" class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <p>Copyright @ 2019 
                    <a href="https://www.kriscent.in/" class="text-theme-clr" target="_blank">
                Kriscent Techno Hub Pvt. Ltd.</a></p>
            </div>
            <div class="col-md-6 text-right">
                <p><a href="javascript:" class="text-theme-clr">Terms</a>&nbsp;&nbsp; &bull; 
                   &nbsp;&nbsp; <a href="javascript:" class="text-theme-clr">Privacy</a></p>
            </div>
        </div>
    </div>
</footer>
<!-- /Footer -->

<?php include('modal.php'); ?>


<!--Bootstrap 4 Script-->
<script src="<?php echo $baseurl; ?>assets/js/jquery.min.js"></script>
<script src="<?php echo $baseurl; ?>assets/js/popper.min.js"></script>
<script src="<?php echo $baseurl; ?>assets/js/bootstrap.min.js"></script>

<!--Third Party Plugin Script-->
<script src="<?php echo $baseurl; ?>assets/js/gijgo.min.js"></script>
<script src="<?php echo $baseurl; ?>assets/js/jquery.slimscroll.js"></script>

<!-- DataTable -->
<script src="<?php echo $baseurl; ?>assets/js/jquery.dataTables.js"></script>
<script src="<?php echo $baseurl; ?>assets/js/dataTables.bootstrap4.js"></script>

<!--Dashboard Script-->
<script src="<?php echo $baseurl; ?>assets/js/script.js"></script>

<!-- Load d3.js and c3.js -->
<script src="<?php echo $baseurl; ?>assets/js/d3.v5.min.js"></script>
<script src="<?php echo $baseurl; ?>assets/js/c3.js"></script>

<!-- Css Variable uses in IE -->
<script src="<?php echo $baseurl; ?>assets/js/iejs/webcomponents-lite.js"></script>
<script src="<?php echo $baseurl; ?>assets/js/iejs/css-var-polyfill.js"></script>


<script>
    $(function(){
    var current = location.pathname;
    
    $('#ulnav-scroll li a').each(function(){
        var $this = $(this);
        // if the current path is like this link, make it active
        if($this.attr('href').indexOf(current) !== -1){
            $this.addClass('active');
        }        
    })
    console.log(current);
    
})
</script>
</body>
</html>





