
<?php include('header.php'); ?>


<!-- Content Section -->
<section id="MainContentBlock" class="ContentBlock">
	<div class="container-fluid p-3 p-lg-4">	

<div class="row">                    
<div class="col-12">
<div class="bg-light p-3 p-lg-4">
	<ul class="nav nav-pills mb-4 my-pills" id="pills-tab" role="tablist">
	<li class="nav-item">
	<a href="#pills-home" class="nav-link active" data-toggle="pill">Profile</a>
	</li>
	<li class="nav-item">
	<a  href="#pills-profile" class="nav-link" data-toggle="pill">Wallet</a>
	</li>
	<li class="nav-item">
	<a href="#pills-contact" class="nav-link" data-toggle="pill">Past Record</a>
	</li>
	</ul>	
	
	<div class="tab-content" id="pills-tabContent">
	<div class="tab-pane fade show active" id="pills-home">
		<h4 class="mb-3">Profile Details</h4>
	<form>
		  <div class="form-group row">
          	<div class="col-12 col-md-6">
          	<div class="row">
		    <label for="Name" class="col-md-4 col-form-label">
		    	Name
		    </label>
		    <div class="col-md-8">
		      <input type="text" class="my-input" id="Name" value="Shariq" placeholder="Name" />
		    </div>
			</div>
			</div>
			<div class="col-md-6">
			<div class="row">
		    <label for="Email" class="col-md-4 col-form-label text-md-center">
		    	Email
		    </label>
		    <div class="col-md-8">
		      <input type="Email" class="my-input" id="Email" value="shariq@kriscent.in" placeholder="Email" />					      
		    </div>
			</div>
		  </div>
		  </div>

		  <div class="form-group row">
          	<div class="col-12 col-md-6">
          	<div class="row">
		    <label for="Mobile" class="col-md-4 col-form-label">
		    	Mobile no.
		    </label>
		    <div class="col-md-8">
		      <input type="text" class="my-input" id="Mobile" value="9001717177" placeholder="Mobile no." />					      
		    </div>
			</div>
			</div>
			<div class="col-md-6">
			<div class="row">
		    <label for="Qty" class="col-md-4 col-form-label text-md-center">
		    	Password
		    </label>
		    <div class="col-md-8">
		      <input type="password" class="my-input" id="Qty" value="Password" placeholder="Password" />					      
		    </div>
			</div>
		  </div>
		  </div>

		  <div class="form-group row">
          	<div class="col-12 col-md-6">
          	<div class="row">
		    <label class="col-md-4 col-form-label">
		    	Area
		    </label>
		    <div class="col-md-8">
		      <select id="select-dropdown">
		      	<option value="0">Select Area</option>
		      	<option value="1">Area #1</option>
		      	<option value="2">Area #2</option>
		      	<option value="3">Area #3</option>		      	
		      </select>					      
		    </div>
			</div>
			</div>
			<div class="col-md-6">
			<div class="row">
		    <label for="Home" class="col-md-4 col-form-label text-md-center">
		    	Home
		    </label>
		    <div class="col-md-8">
		      <input type="text" class="my-input" id="Home" value="12" placeholder="House No." />					      
		    </div>
			</div>
		  </div>
		  </div>		  	  

		  <div class="form-group row">
		  	  <label class="col-md-2 col-form-label">
		      Status <span class="text-danger">*</span></label>
		    <div class="col-md-10 d-flex align-self-center">
			  <div class="radio radio-primary pl-0">
                <input type="radio" name="radio1" id="radio1" value="option1" checked="">
                <label for="radio1">
                    Active
                </label>
              </div>
              <div class="radio radio-primary">
                <input type="radio" name="radio1" id="radio2" value="option1">
                <label for="radio2">
                    Deactive
                </label>
              </div>
          	</div>
          </div>          

          <div class="form-group row">
          	<div class="col-md-2"></div>
          	<div class="col-md-4">
          		<button type="button" class="my-btn btn-theme-clr btn-block">
                     Update Details
                </button>
          	</div>
          </div>
		</form>
	</div>
	<div class="tab-pane fade" id="pills-profile">
		<form>
			<h4 class="mb-3">Wallet Details</h4>
		  <div class="form-group row mb-4">		  	
          	<div class="col-12 col-md-6">          		
          	<div class="row">
		    <label for="Wallet" class="col-md-4 col-form-label">
		    	Wallet
		    </label>
		    <div class="col-md-8">
		      <input type="text" class="my-input" id="Wallet" value="1000" placeholder="Wallet" />
		    </div>
			</div>
			</div>
			<div class="col-12 col-md-4">
				<button type="button" class="my-btn btn-theme-clr">
                     Update Details
                </button>
			</div>			
		  </div>
		</form>

		<div class="table-responsive">
			<table id="datatable3" class="table table-striped table-bordered w-100">
			<?php include('componant/wallet-datatable.php'); ?>
			</table>
		</div>
	</div>
	<div class="tab-pane fade" id="pills-contact">
		<h4 class="mb-3">Order Details</h4>
	<div class="table-responsive">
			<table id="datatable2" class="table table-striped table-bordered w-100">
			<?php include('componant/pastorder-datatable.php'); ?>
			</table>
		</div>
	</div>
	</div> 
</div>
</div>														   
</div>                            
	

	</div>
</section>
<!-- Content Section End-->


<?php include('footer.php'); ?>


