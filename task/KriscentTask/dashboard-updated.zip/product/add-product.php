
<?php include('../header.php'); ?>


<!-- Content Section -->
<section id="MainContentBlock" class="ContentBlock">
	<div class="container-fluid p-3 p-lg-4">				

		<div class="row">			
			<div class="col-12">
				<div class="bg-light p-3 p-lg-4">
					<h4 class="mb-3">Add New Product</h4>
					<form>
					  <div class="form-group row">
					    <label for="CategoriesTitle" class="col-md-2 col-form-label">
					    	Product Name <span class="text-danger">*</span>
					    </label>
					    <div class="col-md-10">
					      <input type="text" class="my-input" id="CategoriesTitle" value="Pet Safa Churna" placeholder="Product Title" />
					    </div>
					  </div>
					  <div class="form-group row">
					    <label for="ParentCategory" class="col-md-2 col-form-label">
					    Parent Category <span class="text-danger">*</span></label>
					    <div class="col-md-10">
					      <select id="select-dropdown">
					      	<option value="no">No Parent</option>
					      	<option value="1">Category #1</option>
					      	<option value="2">Category #2</option>
					      	<option value="3">Category #3</option>		      	
					      </select>
					    </div>
					  </div>
					  <div class="form-group row">					  	
					    <label for="ProductDescription" class="col-md-2 col-form-label">
					    	Product Description
					    </label>
					    <div class="col-md-10">
					      <textarea rows="6" name="" class="my-input" id="ProductDescription" placeholder="Product Description"></textarea>					      
					    </div>
					  </div>
					  <div class="form-group row">
					    <label class="col-md-2 col-form-label">
					    Choose Image </label>
					    <div class="col-md-10">
					    	<div class="media">
					    	<div class="category-img d-flex align-items-center">
					    		<img src="<?php echo $baseurl; ?>assets/images/logo.png" alt="" class="img-fluid mx-auto">
					    	</div>
					    	<div class="media-body align-self-center ml-3 ml-md-4">
					    	<label class="my-btn btn-theme-clr mt-3">
		                        <i class="ti-pencil-alt"></i>
		                        <input type="file" class="d-none" /> Browse
		                    </label></div>
		                    </div>					    	
					    </div>
					  </div>

					  <div class="form-group row">
					  	  <label class="col-md-2 col-form-label">
					      Status <span class="text-danger">*</span></label>
					    <div class="col-md-10 d-flex align-self-center">
						  <div class="radio radio-primary pl-0">
	                        <input type="radio" name="radio1" id="radio1" value="option1" checked="">
	                        <label for="radio1">
	                            In Stock
	                        </label>
	                      </div>
	                      <div class="radio radio-primary">
	                        <input type="radio" name="radio1" id="radio2" value="option1">
	                        <label for="radio2">
	                            Out of Stock
	                        </label>
	                      </div>
	                  	</div>
	                  </div>

	                  <div class="form-group row">
	                  	<div class="col-12 col-md-6">
	                  	<div class="row">
					    <label for="MRP" class="col-md-4 col-form-label">
					    	MRP <span class="text-danger">*</span>
					    </label>
					    <div class="col-md-8">
					      <input type="text" class="my-input" id="MRP" value="150" placeholder="MRP" />					      
					    </div>
						</div>
						</div>
						<div class="col-md-6">
						<div class="row">
					    <label for="Price" class="col-md-4 col-form-label text-md-center">
					    	Price <span class="text-danger">*</span>
					    </label>
					    <div class="col-md-8">
					      <input type="text" class="my-input" id="Price" value="200" placeholder="Price" />					      
					    </div>
						</div>
					  </div>
					  </div>

					  <div class="form-group row">
	                  	<div class="col-12 col-md-6">
	                  	<div class="row">
					    <label for="PriceTax" class="col-md-4 col-form-label">
					    	Price Tax <span class="text-danger">*</span>
					    </label>
					    <div class="col-md-8">
					      <input type="text" class="my-input" id="PriceTax" value="10%" placeholder="Price Tax" />					      
					    </div>
						</div>
						</div>
						<div class="col-md-6">
						<div class="row">
					    <label for="Qty" class="col-md-4 col-form-label text-md-center">
					    	Qty <span class="text-danger">*</span>
					    </label>
					    <div class="col-md-8">
					      <input type="text" class="my-input" id="Qty" value="5" placeholder="Quantity" />					      
					    </div>
						</div>
					  </div>
					  </div>					  

					  <div class="form-group row">
					    <label for="Units" class="col-md-2 col-form-label">
					    	Units<span class="text-danger">*</span>
					    </label>
					    <div class="col-md-10">
					      <input type="text" class="my-input" id="Units" value="" placeholder="KG/ BAG/ NOS/ QTY / etc" />					      
					    </div>
					  </div>

	                  <div class="form-group row">
	                  	<div class="col-md-2"></div>
	                  	<div class="col-md-4">
	                  		<button type="button" class="my-btn btn-theme-clr btn-block">
		                         Add Product
		                    </button>
	                  	</div>
	                  </div>
					</form>
				</div>
			</div>
		</div>

	</div>
</section>
<!-- Content Section End-->


<?php include('../footer.php'); ?>


