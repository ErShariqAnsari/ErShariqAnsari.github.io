<!-- Society Modal -->
<div class="modal fade" id="mySociety">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header px-3 px-lg-4">
        <h4>Edit Delivery Details</h4>
        <a href="javascript:" class="close" data-dismiss="modal">
          <span class="ti-close f-16px"></span>
        </a>
      </div>

      <div class="modal-body p-3 p-lg-4">       
          <form>
            <div class="form-group row">
              <label for="Society" class="col-md-3 col-form-label">
                Society Name <span class="text-danger">*</span>
              </label>
              <div class="col-md-9">
                <input type="text" class="my-input" id="Society" value="Gumanpura" placeholder="Society" />
              </div>
            </div> 

            <div class="form-group row">
              <label for="Pin" class="col-md-3 col-form-label">
                Pin/Zip code <span class="text-danger">*</span>
              </label>
              <div class="col-md-9">
                <input type="text" class="my-input" id="Pin" value="324004" placeholder="Pin/Zip code" />
              </div>
            </div>

            <div class="form-group row">
              <label for="Delivery" class="col-md-3 col-form-label">
                Delivery Charge <span class="text-danger">*</span>
              </label>
              <div class="col-md-9">
                <input type="text" class="my-input" id="Delivery" value="20" placeholder="Delivery" />
              </div>
            </div>

            <div class="row">
              <div class="col-md-3"></div>
              <div class="col-md-9">
                <button type="button" class="my-btn btn-theme-clr">
                     Update Details
                </button>
              </div>
            </div>
          </form>
      </div>     

    </div>
  </div>
</div>


<!-- Add City Modal -->
<div class="modal fade" id="myCity">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header px-3 px-lg-4">
        <h4>Add City</h4>
        <a href="javascript:" class="close" data-dismiss="modal">
          <span class="ti-close f-16px"></span>
        </a>
      </div>

      <div class="modal-body p-3 p-lg-4">       
          <form>
            <div class="form-group row">
              <label for="City" class="col-md-3 col-form-label">
                City Name
              </label>
              <div class="col-md-9">
                <input type="text" class="my-input" id="City" value="Gumanpura" placeholder="City Name" />
              </div>
            </div>

            <div class="row">
              <div class="col-md-3"></div>
              <div class="col-md-9">
                <button type="button" class="my-btn btn-theme-clr">
                     Add City
                </button>
              </div>
            </div>
          </form>
      </div>     

    </div>
  </div>
</div>



<!-- Edit Modal -->
<div class="modal fade" id="myEditStock">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header px-3 px-lg-4">
        <h4>Edit Stock Details</h4>
        <a href="javascript:" class="close" data-dismiss="modal">
          <span class="ti-close f-16px"></span>
        </a>
      </div>

      <div class="modal-body p-3 p-lg-4">       
          <form>
            <div class="form-group row">
              <label for="Product" class="col-md-3 col-form-label">
                Product Name <span class="text-danger">*</span>
              </label>
              <div class="col-md-9">
                <input type="text" class="my-input" id="Product" value="Face Wash" placeholder="Product Name" />
              </div>
            </div> 

            <div class="form-group row">
              <label for="qty" class="col-md-3 col-form-label">
                QTY <span class="text-danger">*</span>
              </label>
              <div class="col-md-9">
                <input type="text" class="my-input" id="qty" value="12" placeholder="Quantity" />
              </div>
            </div>

            <div class="form-group row">
              <label for="Unit" class="col-md-3 col-form-label">
                Unit <span class="text-danger">*</span>
              </label>
              <div class="col-md-9">
                <input type="text" class="my-input" id="Unit" value="Pack" placeholder="eg:kg/bottle/pack etc." />
              </div>
            </div>

            <div class="row">
              <div class="col-md-3"></div>
              <div class="col-md-9">
                <button type="button" class="my-btn btn-theme-clr">
                     Update Details
                </button>
              </div>
            </div>
          </form>
      </div>     

    </div>
  </div>
</div>