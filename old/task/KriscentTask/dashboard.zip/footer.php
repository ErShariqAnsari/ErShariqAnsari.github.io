<!-- Footer -->
<footer id="footer" class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <p>Copyright @ 2019 
                    <a href="https://www.kriscent.in/" class="text-theme-clr" target="_blank">
                Kriscent Techno Hub Pvt. Ltd.</a></p>
            </div>
            <div class="col-md-6 text-right">
                <p><a href="javascript:" class="text-theme-clr">Terms</a>&nbsp;&nbsp; &bull; 
                   &nbsp;&nbsp; <a href="javascript:" class="text-theme-clr">Privacy</a></p>
            </div>
        </div>
    </div>
</footer>
<!-- /Footer -->



<!--Bootstrap 4 Script-->
<script src="<?php echo $baseurl; ?>assets/js/jquery.min.js"></script>
<script src="<?php echo $baseurl; ?>assets/js/popper.min.js"></script>
<script src="<?php echo $baseurl; ?>assets/js/bootstrap.min.js"></script>

<!--Third Party Plugin Script-->
<script src="<?php echo $baseurl; ?>assets/js/gijgo.min.js"></script>
<script src="<?php echo $baseurl; ?>assets/js/jquery.slimscroll.js"></script>

<!-- DataTable -->
<script src="<?php echo $baseurl; ?>assets/js/jquery.dataTables.js"></script>
<script src="<?php echo $baseurl; ?>assets/js/dataTables.bootstrap4.js"></script>

<!--Dashboard Script-->
<script src="<?php echo $baseurl; ?>assets/js/script.js"></script>

</body>
</html>





