<?php include('../header.php'); ?>

<section id="MainContentBlock" class="ContentBlock">
<div class="container-fluid p-3 p-lg-4">
<div class="row">
<div class="col-12 col-md-6">
<div class="bg-light p-3 p-lg-4">
<h4 class="mb-4">Rippel Effect Button</h4>
<button class="my-btn bg-sweet-morning px-5 py-3 white waves-effect waves-light text-white w300" type="button">Button</button>
<button class="my-btn bg-gd-blue white waves-effect waves-light w300 text-white" type="button">Button</button>
<button class="my-btn bg-gd-danger white waves-effect waves-light w300 text-white" type="button">Button</button>
<button class="my-btn bg-gd-secondary white waves-effect waves-light w300 text-white" type="button">Button</button>
<button class="my-btn bg-gd-cyan white waves-effect waves-light w300 text-white" type="button">Button</button>

<a href="javscript:" class="my-btn border black waves-effect waves-light w300">Button</a>
<a href="javscript:" class="my-btn bg-gd-blue white waves-effect waves-light w300 text-white">Button</a>
<a href="javscript:" class="my-btn bg-gd-danger white waves-effect waves-light w300 text-white">Button</a>
<a href="javscript:" class="my-btn bg-gd-secondary white waves-effect waves-light w300 text-white">Button</a>
<a href="javscript:" class="my-btn bg-gd-cyan px-5 py-3 white waves-effect waves-light w300 text-white">Button</a>
</div>
</div>

<div class="col-12 col-md-6">
<div class="bg-light p-3 p-lg-4">
<h4 class="mb-4">Simple Bootstrap Button</h4>
<button class="my-btn btn-primary" type="button">Button</button>
<button class="my-btn btn-secondary" type="button">Button</button>
<button class="my-btn btn-info" type="button">Button</button>
<button class="my-btn btn-danger" type="button">Button</button>
<button class="my-btn btn-warning" type="button">Button</button>
<button class="my-btn btn-light" type="button">Button</button>
</div>
</div>
</div>
</div>
</section>


<?php include('../footer.php'); ?>

